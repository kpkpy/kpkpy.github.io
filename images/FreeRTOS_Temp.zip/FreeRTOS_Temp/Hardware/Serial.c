#include "stm32f10x.h"                  // Device header
#include "stdio.h"
#include "stdarg.h"

void Serial_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
		
	GPIO_InitTypeDef GPIO_Structure;
	GPIO_Structure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Structure.GPIO_Pin = GPIO_Pin_9;
	GPIO_Structure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_Structure);
	
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
		
}

void Serial_ByteSend(uint8_t byte)
{
	USART_SendData(USART1, byte);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
	
}

void Serial_SendArray(uint8_t *array, uint16_t len)
{
	uint16_t i;
	for(i = 0 ; i < len; i++)
	{
		Serial_ByteSend(array[i]);
	}
}

void Serial_SendString(char *str)
{
	uint16_t i;
	for(i = 0; str[i] != '\0'; i++)
	{
		Serial_ByteSend(str[i]);
	}
}

uint32_t __pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1; 
	while (Y -- )
	{
		Result *= X;
	}
	return Result;
}

void Serial_SendNumber(uint32_t num, uint8_t len)
{
	uint8_t i;
	for(i = 0; i<len; i++)
	{
		Serial_ByteSend(num / __pow(10, len - i -1) %10 + '0');
	}
}

int fputc(int ch, FILE *f)
{
	Serial_ByteSend(ch);
	return ch;
}

void Serial_Printf(char *format, ...)
{
	char String[100];
	va_list arg;
	va_start(arg, format);
	vsprintf(String, format, arg);
	va_end(arg);
	Serial_SendString(String);
}


