#ifndef __SERIAL_H
#define __SERIAL_H

#include "stdio.h"


void Serial_Init(void);

void Serial_ByteSend(uint8_t byte);

void Serial_SendArray(uint8_t *array, uint16_t len);

void Serial_SendString(char *str);

void Serial_SendNumber(uint32_t num, uint8_t len);


#endif
